import React, { useState } from 'react'
import { eventBus } from '../core/eventBus'
import { pluginHost } from '../runtime/pluginHost'

/**
 * The LivingShell component defines the main application layout with a sidebar
 * for managing plugins and a main content area where plugin UIs are rendered.
 */
export function LivingShell() {
  const [pluginUrl, setPluginUrl] = useState('')
  const [loadedIds, setLoadedIds] = useState<string[]>([])

  const loadPlugin = async () => {
    if (!pluginUrl.trim()) return
    const id = `plugin-${Date.now()}`
    try {
      await pluginHost.load(id, pluginUrl, eventBus, getContainer())
      setLoadedIds([...pluginHost.list()])
      setPluginUrl('')
    } catch (err) {
      console.error('Failed to load plugin', err)
    }
  }

  const unloadPlugin = (id: string) => {
    pluginHost.unload(id)
    setLoadedIds([...pluginHost.list()])
  }

  const getContainer = () => {
    return document.getElementById('plugin-container') as HTMLElement
  }

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      <aside style={{ width: '16rem', background: '#f3f4f6', padding: '1rem' }}>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: '0.5rem' }}>Plugins</h2>
        <input
          type="text"
          placeholder="Plugin URL"
          value={pluginUrl}
          onChange={e => setPluginUrl(e.target.value)}
          style={{ width: '100%', padding: '0.25rem', marginBottom: '0.5rem', border: '1px solid #ddd' }}
        />
        <button
          onClick={loadPlugin}
          style={{ width: '100%', padding: '0.5rem', marginBottom: '0.5rem', background: '#2563eb', color: '#fff', border: 'none', cursor: 'pointer' }}
        >
          Load Plugin
        </button>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {loadedIds.map(id => (
            <li key={id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.25rem' }}>
              <span>{id}</span>
              <button onClick={() => unloadPlugin(id)} style={{ background: 'transparent', border: 'none', color: '#dc2626', cursor: 'pointer' }}>
                ×
              </button>
            </li>
          ))}
        </ul>
      </aside>
      <main style={{ flex: 1, padding: '1rem', overflow: 'auto' }}>
        <div id="plugin-container" style={{ minHeight: '100%' }} />
      </main>
    </div>
  )
}