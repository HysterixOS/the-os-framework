import React from 'react'
import ReactDOM from 'react-dom/client'
import { LivingShell } from './ui/LivingShell'
import { monitorEventBus, optimisationManager } from './core/selfOptimization'

// Mount the living shell to the root element
// Initialise global instrumentation and optimisation strategies
monitorEventBus()
// A simple example strategy that logs metrics to the console.  In a
// real system, strategies could dynamically adjust polling intervals,
// prioritise plugins or perform garbage collection.
optimisationManager.register(metrics => {
  console.debug('[SelfOptimisation] Metrics snapshot', metrics)
})

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <LivingShell />
  </React.StrictMode>,
)