import { eventBus } from './eventBus'

/**
 * MetricsCollector gathers runtime statistics that can be used by
 * self‑optimisation strategies.  Metrics include the number of
 * plugins loaded, counts of events emitted and overall uptime.
 */
export class MetricsCollector {
  /** Number of plugins that have been loaded since the collector was created */
  pluginLoads = 0
  /** Counts of events emitted through the event bus */
  eventCounts: Record<string, number> = {}
  /** Timestamp when metrics collection started */
  startTime = Date.now()

  /** Increment the count of loaded plugins */
  incrementPluginLoads() {
    this.pluginLoads++
  }

  /** Increment the count for a particular event name */
  incrementEvent(event: string) {
    this.eventCounts[event] = (this.eventCounts[event] ?? 0) + 1
  }

  /** Return a snapshot of the collected metrics */
  snapshot() {
    return {
      pluginLoads: this.pluginLoads,
      eventCounts: { ...this.eventCounts },
      startTime: this.startTime,
      uptime: Date.now() - this.startTime,
    }
  }
}

/** Global metrics collector instance */
export const metricsCollector = new MetricsCollector()

/**
 * Wraps the global event bus to collect event emission counts.  This
 * function should be called once at application startup.  Subsequent
 * calls have no effect.  Emitted events will be recorded in the
 * metrics collector before being forwarded to the original event bus.
 */
let monitored = false
export function monitorEventBus() {
  if (monitored) return
  monitored = true
  const origEmit = eventBus.emit.bind(eventBus)
  ;(eventBus as any).emit = (event: string, payload: any) => {
    metricsCollector.incrementEvent(event)
    origEmit(event, payload)
  }
}

/**
 * A strategy receives a metrics snapshot and may perform arbitrary
 * optimisation actions such as adjusting polling intervals or
 * unloading unused plugins.  For demonstration purposes, strategies
 * typically log metrics or update internal state, but real
 * implementations could perform more sophisticated tasks.
 */
export type OptimisationStrategy = (
  metrics: ReturnType<MetricsCollector['snapshot']>,
) => void

class OptimisationManager {
  private strategies: OptimisationStrategy[] = []

  /**
   * Register an optimisation strategy.  Strategies will be invoked
   * sequentially when `run` is called.
   */
  register(strategy: OptimisationStrategy) {
    this.strategies.push(strategy)
  }

  /**
   * Execute all registered strategies with the current metrics
   * snapshot.  Individual strategies are responsible for their own
   * error handling.
   */
  run() {
    const snapshot = metricsCollector.snapshot()
    for (const strategy of this.strategies) {
      try {
        strategy(snapshot)
      } catch (err) {
        console.error('Optimisation strategy failed', err)
      }
    }
  }
}

/** Global optimisation manager instance */
export const optimisationManager = new OptimisationManager()