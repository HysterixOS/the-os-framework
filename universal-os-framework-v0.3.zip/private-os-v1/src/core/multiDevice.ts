/**
 * Multi‑device framework for the universal OS.
 *
 * This module introduces a high‑level abstraction for discovering nearby
 * devices, establishing secure peer‑to‑peer connections and creating
 * sessions that can be transferred or shared across multiple devices.
 *
 * The APIs defined here are intentionally minimal and platform agnostic.
 * Real implementations would need to integrate with platform‑specific
 * Bluetooth, Wi‑Fi or other communication stacks.  The goal of this
 * framework is to provide a consistent surface for plugins and core
 * modules to interact with other devices without having to worry
 * about the underlying transport mechanisms.
 */

import { eventBus } from './eventBus'

/**
 * Describes a discoverable remote device.  The `type` field is a
 * qualitative hint about the device form factor and may be used to
 * tailor UI or behaviour (e.g. phone vs tablet vs TV).  Additional
 * metadata can be included as needed.
 */
export interface Device {
  /** Unique identifier for the device (e.g. MAC address or random UUID) */
  id: string
  /** Human‑readable name reported by the device */
  name: string
  /** Form factor hint */
  type: 'phone' | 'tablet' | 'watch' | 'tv' | 'laptop' | 'unknown'
}

/**
 * DeviceDiscovery is responsible for finding nearby devices.  It emits
 * `deviceFound` events on the global event bus when a new device is
 * detected and `deviceLost` when a previously discovered device is no
 * longer reachable.  In a real implementation this class would wrap
 * platform APIs such as Bluetooth LE scanning or local network service
 * discovery.
 */
export class DeviceDiscovery {
  private discovering = false
  /** Start scanning for nearby devices.  Subsequent calls have no effect. */
  start() {
    if (this.discovering) return
    this.discovering = true
    // Placeholder: simulate device discovery by emitting a dummy device
    setTimeout(() => {
      const device: Device = {
        id: 'device-' + Math.random().toString(36).slice(2),
        name: 'Simulated device',
        type: 'unknown',
      }
      eventBus.emit('deviceFound', device)
    }, 1000)
  }
  /** Stop scanning for devices.  This would cancel any ongoing discovery. */
  stop() {
    this.discovering = false
    // In a real implementation you would cancel the scan here
  }
}

/**
 * SecureConnection represents an encrypted, low‑latency link between
 * two devices.  Clients can send arbitrary byte arrays to the remote
 * device and subscribe to incoming messages.  Errors are surfaced via
 * the `onError` callback.  This class does not specify a concrete
 * transport; platforms can implement it using Bluetooth, Wi‑Fi Direct,
 * WebRTC or any other protocol.
 */
export class SecureConnection {
  private onMessageCallbacks: ((data: Uint8Array) => void)[] = []
  private onErrorCallbacks: ((err: Error) => void)[] = []

  /** Send a message to the remote device.  No guarantee of delivery is made. */
  send(data: Uint8Array) {
    // Placeholder: in a real implementation this would write to a socket
    // For now we simply log the message
    console.debug('SecureConnection.send', data)
  }

  /** Register a callback for incoming messages. */
  onMessage(cb: (data: Uint8Array) => void) {
    this.onMessageCallbacks.push(cb)
  }

  /** Register a callback for connection errors. */
  onError(cb: (err: Error) => void) {
    this.onErrorCallbacks.push(cb)
  }

  /**
   * Internal helper to dispatch received messages.  Platform
   * implementations should call this when new data arrives.
   */
  protected dispatchMessage(data: Uint8Array) {
    for (const cb of this.onMessageCallbacks) cb(data)
  }
  /**
   * Internal helper to dispatch errors.  Platform implementations should
   * call this when an error occurs.
   */
  protected dispatchError(err: Error) {
    for (const cb of this.onErrorCallbacks) cb(err)
  }
}

/**
 * A session represents a user experience that can be transferred or
 * shared between devices.  The `tag` identifies the logical session
 * and is defined by the application.  Participants represent the
 * devices that are currently part of the session.  Sessions emit
 * `sessionUpdated`, `sessionTransferred` and `sessionEnded` events
 * via the event bus.
 */
export class Session {
  /** Unique ID assigned by the session manager */
  readonly id: string
  /** Application‑defined tag used to differentiate sessions */
  readonly tag: string
  /** Participants currently in the session */
  readonly participants: Device[] = []
  constructor(tag: string) {
    this.id = 'session-' + Math.random().toString(36).slice(2)
    this.tag = tag
  }
}

/**
 * MultiDeviceManager orchestrates device discovery, secure connections
 * and session management.  Applications can use this singleton to
 * register callback hooks and initiate session transfers.  Actual
 * network operations are stubbed out in this minimal implementation.
 */
class MultiDeviceManager {
  private discovery = new DeviceDiscovery()
  private sessions: Record<string, Session> = {}

  /** Start scanning for devices.  Triggers `deviceFound` events. */
  startDiscovery() {
    this.discovery.start()
  }
  /** Stop device discovery. */
  stopDiscovery() {
    this.discovery.stop()
  }
  /** Create a new session with the given tag and emit a `sessionUpdated` event. */
  createSession(tag: string): Session {
    const session = new Session(tag)
    this.sessions[session.id] = session
    eventBus.emit('sessionUpdated', session)
    return session
  }
  /** Transfer an existing session to a selected device. */
  transferSession(sessionId: string, device: Device) {
    const session = this.sessions[sessionId]
    if (!session) throw new Error('Invalid session ID')
    // Simulate removing the session from local participants and adding the new device
    session.participants.push(device)
    eventBus.emit('sessionTransferred', { session, device })
    // In a real implementation, you would establish a connection and move state
  }
  /** End a session and notify listeners. */
  endSession(sessionId: string) {
    const session = this.sessions[sessionId]
    if (!session) return
    delete this.sessions[sessionId]
    eventBus.emit('sessionEnded', session)
  }
  /** List all active sessions. */
  listSessions(): Session[] {
    return Object.values(this.sessions)
  }
}

/**
 * A global instance of the multi‑device manager.  Applications should
 * import this instead of instantiating their own managers.  This
 * ensures that device discovery and sessions are shared system‑wide.
 */
export const multiDeviceManager = new MultiDeviceManager()