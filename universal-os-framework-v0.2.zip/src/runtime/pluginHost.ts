import type { EventBus } from '../core/eventBus'
import { securityManager } from '../core/security'
import { metricsCollector } from '../core/selfOptimization'

export interface PluginModule {
  mount: (bus: EventBus, container: HTMLElement) => void | (() => void)
  unmount?: () => void
  upgrade?: (from: string) => void
}

/**
 * PluginHost is responsible for loading, unloading and upgrading plugins.
 * Plugins are ES modules that export at least a `mount` function.  They
 * receive the event bus and a container element and may optionally
 * return an unmount callback.  Loaded plugins are tracked by ID.
 */
class PluginHost {
  private registry: Record<string, { mod: PluginModule; container: HTMLElement }> = {}

  async load(id: string, url: string, bus: EventBus, target: HTMLElement) {
    if (this.registry[id]) {
      console.warn(`Plugin ${id} already loaded`) 
      return
    }

    // Consult the security policy before attempting to load a plugin.
    if (!securityManager.canLoad(url)) {
      throw new Error(`Loading plugin from ${url} disallowed by security policy`)
    }
    // Dynamically import the plugin module.  The vite-ignore comment
    // prevents Vite from trying to statically analyze the import.
    const mod: PluginModule = await import(/* @vite-ignore */ url)
    const container = document.createElement('div')
    target.appendChild(container)

    // Create a secured proxy around the event bus that enforces the
    // current security policy on event emission.  All other properties
    // are delegated to the original bus.
    const securedBus: EventBus = new Proxy(bus, {
      get(targetBus, prop) {
        if (prop === 'emit') {
          return (event: string, payload: any) => {
            if (securityManager.canEmit(event)) {
              ;(targetBus as any).emit(event, payload)
            } else {
              console.warn(`Event '${event}' blocked by security policy`)
            }
          }
        }
        // @ts-ignore: delegate unknown properties to the original bus
        return (targetBus as any)[prop]
      },
    }) as any

    const maybeUnmount = mod.mount(securedBus, container)

    // Increment plugin load metrics after a successful mount
    metricsCollector.incrementPluginLoads()

    this.registry[id] = {
      mod: { ...mod, unmount: mod.unmount ?? (maybeUnmount as any) },
      container,
    }
  }

  unload(id: string) {
    const entry = this.registry[id]
    if (!entry) return
    entry.mod.unmount?.()
    entry.container.remove()
    delete this.registry[id]
  }

  upgrade(id: string, from: string) {
    const entry = this.registry[id]
    entry?.mod.upgrade?.(from)
  }

  list(): string[] {
    return Object.keys(this.registry)
  }
}

export const pluginHost = new PluginHost()