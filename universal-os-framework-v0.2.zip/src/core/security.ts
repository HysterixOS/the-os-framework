/**
 * Security framework for the universal OS.
 *
 * This module implements a simple security manager that can be used to
 * control which plugins are allowed to load and which events they can
 * emit.  The default policy allows all plugins and events.  Consumers
 * may override the policy at runtime to enforce stricter rules.
 */

export interface PluginSecurityPolicy {
  /**
   * A list of regular expressions describing allowed origins for plugin
   * modules.  If omitted, plugins may be loaded from any origin.
   */
  allowedOrigins?: RegExp[]
  /**
   * A list of event names that plugins are permitted to emit.  If
   * undefined, any event name is allowed.  If defined, attempts to
   * emit an event name not in the list will be blocked.
   */
  allowedEventNames?: string[]
}

class PluginSecurityManager {
  private policy: PluginSecurityPolicy

  constructor(policy?: PluginSecurityPolicy) {
    // Start with an empty (fully permissive) policy by default
    this.policy = policy ?? {}
  }

  /**
   * Determine whether a plugin may be loaded from the provided URL.
   * The origin of the URL must match one of the allowedOrigins
   * patterns, if any are configured.  Invalid URLs are rejected.
   */
  canLoad(url: string): boolean {
    const { allowedOrigins } = this.policy
    if (!allowedOrigins || allowedOrigins.length === 0) return true
    try {
      const origin = new URL(url, window.location.origin).origin
      return allowedOrigins.some(re => re.test(origin))
    } catch {
      return false
    }
  }

  /**
   * Determine whether the given event name may be emitted by a plugin.
   * If allowedEventNames is undefined, all events are allowed.
   */
  canEmit(eventName: string): boolean {
    const { allowedEventNames } = this.policy
    if (!allowedEventNames || allowedEventNames.length === 0) return true
    return allowedEventNames.includes(eventName)
  }

  /**
   * Replace the current security policy with a new one.  Calling this
   * function will immediately change the behaviour of canLoad and
   * canEmit.  Consumers should be careful to validate policies prior
   * to applying them.
   */
  setPolicy(policy: PluginSecurityPolicy) {
    this.policy = policy
  }

  /**
   * Returns a shallow copy of the current policy.  This allows
   * consumers to inspect the active policy without mutating it.
   */
  getPolicy(): PluginSecurityPolicy {
    return { ...this.policy }
  }
}

/**
 * A global singleton instance of the security manager.  Modules
 * throughout the system can import this instance to query or
 * configure the security policy.
 */
export const securityManager = new PluginSecurityManager()