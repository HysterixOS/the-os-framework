/**
 * Interoperability framework for the universal OS.
 *
 * This module provides a registry of simple adapters used to
 * translate data between external sources (e.g. third-party services
 * or plugins written in other languages) and the internal
 * representation used by the core.  Each adapter knows how to
 * convert data to and from the internal format.  The framework can
 * support multiple adapter types simultaneously and allows querying
 * the list of registered adapters.
 */

export interface Adapter<T = any, U = any> {
  /** Convert an external value (T) into the internal representation (U). */
  toInternal: (data: T) => U
  /** Convert an internal value (U) back into the external representation (T). */
  fromInternal: (data: U) => T
}

class InteroperabilityManager {
  private adapters: Record<string, Adapter<any, any>> = {}

  /**
   * Register an adapter under a unique type identifier.  Passing
   * different type identifiers enables multiple distinct adapters
   * operating in parallel.
   */
  register<T, U>(type: string, adapter: Adapter<T, U>) {
    this.adapters[type] = adapter
  }

  /**
   * Convert data from an external representation to the internal
   * format using a registered adapter.  If no adapter exists for the
   * given type, the original data is returned unchanged.
   */
  toInternal<T>(type: string, data: T): any {
    const adapter = this.adapters[type]
    return adapter ? adapter.toInternal(data) : data
  }

  /**
   * Convert data from the internal representation back to an external
   * representation using a registered adapter.  If no adapter
   * exists for the given type, the original data is returned
   * unchanged.
   */
  fromInternal<U>(type: string, data: U): any {
    const adapter = this.adapters[type]
    return adapter ? adapter.fromInternal(data) : data
  }

  /**
   * Return a list of all registered adapter type identifiers.
   */
  list(): string[] {
    return Object.keys(this.adapters)
  }
}

/**
 * A global instance of the interoperability manager.  Consumers
 * should import this instance rather than creating their own in order
 * to share adapters system‑wide.
 */
export const interopManager = new InteroperabilityManager()