/**
 * Defines the shape of the upgrade manifest.  The manifest lists the
 * currently available stable and canary versions.  Additional fields
 * could be added in the future to describe migrations or dependency
 * graphs between versions.
 */
export interface UpgradeManifest {
  stable: string
  canary: string
  [channel: string]: string
}

/**
 * Fetches the upgrade manifest from the server.  The manifest is served
 * from the `public` directory.  Consumers can use this to determine
 * whether an upgrade is available and decide which channel to target.
 */
export async function fetchUpgradeManifest(): Promise<UpgradeManifest> {
  const response = await fetch('/upgrade-manifest.json')
  if (!response.ok) throw new Error(`Failed to fetch upgrade manifest: ${response.status}`)
  return (await response.json()) as UpgradeManifest
}