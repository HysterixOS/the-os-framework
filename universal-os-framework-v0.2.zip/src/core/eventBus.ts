export type EventHandler<T = any> = (payload: T) => void

/**
 * A minimal pub/sub event bus for communication between plugins.
 */
class EventBus {
  private handlers: Map<string, Set<EventHandler>> = new Map()

  /**
   * Register a handler for the given event.  Returns a function that will
   * remove the handler when called.
   */
  on<T>(event: string, handler: EventHandler<T>): () => void {
    const set = this.handlers.get(event) ?? new Set()
    set.add(handler as any)
    this.handlers.set(event, set)
    return () => set.delete(handler as any)
  }

  /**
   * Emit an event with an optional payload.
   */
  emit<T>(event: string, payload: T): void {
    const set = this.handlers.get(event)
    if (!set) return
    for (const handler of set) {
      handler(payload)
    }
  }
}

export const eventBus = new EventBus()