# Private OS

Private OS is a lightweight universal OS framework built with **Vite** and **React** (TypeScript).  It provides a living shell UI with a plugin runtime, a simple event bus, a self‑upgrade path via an upgrade manifest, and a pair of example plugins.  Use it as a starting point to build your own modular desktop or web application.

## Features

- **Living Shell UI** – A React shell with a sidebar for loading and unloading plugins at runtime.  Plugins render into a dedicated container and can be added by specifying a remote URL.
- **Plugin Runtime** – Dynamically import ES modules as plugins.  Each plugin exports a `mount(bus, container)` function (and may optionally export `unmount` or `upgrade`).
- **Event Bus** – A tiny publish/subscribe system used to broadcast events between plugins (e.g. a `tick` event emitted by the clock plugin).
- **Self‑Upgrade Path** – Reads `public/upgrade-manifest.json` to determine the current stable and canary versions.  The upgrade manager is stubbed out for future extension.
- **Example Plugins** –
  - *SamplePanel* (UI): Displays the number of tick events received.
  - *ClockPlugin* (headless): Emits a `tick` event every second.

### New frameworks in v0.2

- **Security Framework** – Provides a global `securityManager` that can restrict which plugin origins are allowed and which event names plugins may emit.  When loading a plugin the host consults the security policy and denies disallowed loads.  Event emissions from plugins are proxied through a secured bus that blocks unauthorised events.
- **Interoperability Framework** – A registry for adapters that translate data between external systems and the internal representation.  Register adapters via `interopManager.register(type, adapter)` and use `toInternal`/`fromInternal` to convert values.  This lays the groundwork for cross‑language plugin interoperability.
- **Self‑Optimisation Framework** – Collects runtime metrics (plugin loads, event counts, uptime) and exposes them via a global `metricsCollector`.  The `monitorEventBus` function instruments the event bus to record emission counts.  An `optimisationManager` allows registration of strategies that run against the current metrics snapshot to tune system behaviour.

## Getting Started

1. Install dependencies with `npm install`.
2. Start the development server using `npm run dev`.
3. Open your browser at the address printed by Vite (usually `http://localhost:5173`).
4. Load the sample plugins or any remote ES module that exports a `mount` function by pasting its URL into the plugin loader.

## Project Structure

- `public/upgrade-manifest.json` – Declares the available stable and canary versions.
- `src/core/eventBus.ts` – Implements a minimal pub/sub event bus.
- `src/core/capabilityGraph.ts` – Resolves dependencies between capabilities (unused in the default UI but provided for extensibility).
- `src/core/upgrade.ts` – Reads the upgrade manifest (stubbed for future enhancements).
- `src/core/security.ts` – Implements a simple plugin security manager with configurable allowed origins and event names.
- `src/core/interoperability.ts` – Provides an adapter registry to translate data between external systems and the internal representation.
- `src/core/selfOptimization.ts` – Collects runtime metrics and provides a manager to run optimisation strategies.
- `src/runtime/pluginHost.ts` – Loads, unloads and upgrades plugins dynamically.
- `src/ui/LivingShell.tsx` – The main application shell with plugin management UI.
- `src/plugins/SamplePanel.tsx` – Example plugin with UI showing tick counts.
- `src/plugins/ClockPlugin.ts` – Example headless plugin emitting `tick` events.
- `src/main.tsx` – Entry point that renders the `LivingShell`.
- Build configuration files: `package.json`, `vite.config.ts`, `tsconfig.json` and `tsconfig.node.json`.

## License

This project is licensed under the MIT License.  Feel free to modify and extend it for your own purposes.