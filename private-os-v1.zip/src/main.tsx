import React from 'react'
import ReactDOM from 'react-dom/client'
import { LivingShell } from './ui/LivingShell'

// Mount the living shell to the root element
ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <LivingShell />
  </React.StrictMode>,
)