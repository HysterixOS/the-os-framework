export interface Capability {
  id: string
  requires?: string[]
}

/**
 * Resolves a list of capabilities into a topological order based on their
 * `requires` dependencies.  Capabilities that depend on others will be
 * ordered after their dependencies.  Any cycles will result in the
 * capabilities being returned in the order they were provided.
 */
export function resolveOrder(capabilities: Capability[]): string[] {
  const visited = new Set<string>()
  const order: string[] = []

  function visit(id: string) {
    if (visited.has(id)) return
    const cap = capabilities.find(c => c.id === id)
    cap?.requires?.forEach(dep => visit(dep))
    visited.add(id)
    order.push(id)
  }

  capabilities.forEach(cap => visit(cap.id))
  return order
}