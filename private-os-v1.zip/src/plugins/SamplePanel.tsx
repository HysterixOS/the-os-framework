import React from 'react'
import ReactDOM from 'react-dom/client'
import type { EventBus } from '../core/eventBus'

/**
 * SamplePanel is an example UI plugin that displays the number of tick
 * events received from the event bus.  It is mounted via the plugin
 * runtime and cleaned up automatically when unmounted.
 */
export function mount(bus: EventBus, container: HTMLElement) {
  ReactDOM.createRoot(container).render(<SamplePanel bus={bus} />)
  // No explicit unmount function is returned because ReactDOM will clean up
  // when the container element is removed by the PluginHost.
}

function SamplePanel({ bus }: { bus: EventBus }) {
  const [ticks, setTicks] = React.useState(0)
  React.useEffect(() => {
    const off = bus.on('tick', () => setTicks(t => t + 1))
    return off
  }, [bus])
  return (
    <div style={{ padding: '1rem', background: '#fff', borderRadius: '0.5rem', boxShadow: '0 1px 2px rgba(0,0,0,0.1)' }}>
      <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '0.5rem' }}>Sample Panel</h3>
      <p>Tick count: {ticks}</p>
    </div>
  )
}