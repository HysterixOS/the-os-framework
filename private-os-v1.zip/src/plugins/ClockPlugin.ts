import type { EventBus } from '../core/eventBus'

/**
 * ClockPlugin is a headless plugin that emits a `tick` event on the
 * event bus every second.  It returns an unmount function that
 * clears the interval when the plugin is unloaded.
 */
export function mount(bus: EventBus, _container: HTMLElement) {
  const interval = setInterval(() => {
    bus.emit('tick', null)
  }, 1000)
  return () => clearInterval(interval)
}