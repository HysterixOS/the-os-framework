import type { EventBus } from '../core/eventBus'

export interface PluginModule {
  mount: (bus: EventBus, container: HTMLElement) => void | (() => void)
  unmount?: () => void
  upgrade?: (from: string) => void
}

/**
 * PluginHost is responsible for loading, unloading and upgrading plugins.
 * Plugins are ES modules that export at least a `mount` function.  They
 * receive the event bus and a container element and may optionally
 * return an unmount callback.  Loaded plugins are tracked by ID.
 */
class PluginHost {
  private registry: Record<string, { mod: PluginModule; container: HTMLElement }> = {}

  async load(id: string, url: string, bus: EventBus, target: HTMLElement) {
    if (this.registry[id]) {
      console.warn(`Plugin ${id} already loaded`) 
      return
    }
    // Dynamically import the plugin module.  The vite-ignore comment
    // prevents Vite from trying to statically analyze the import.
    const mod: PluginModule = await import(/* @vite-ignore */ url)
    const container = document.createElement('div')
    target.appendChild(container)
    const maybeUnmount = mod.mount(bus, container)
    this.registry[id] = { mod: { ...mod, unmount: mod.unmount ?? (maybeUnmount as any) }, container }
  }

  unload(id: string) {
    const entry = this.registry[id]
    if (!entry) return
    entry.mod.unmount?.()
    entry.container.remove()
    delete this.registry[id]
  }

  upgrade(id: string, from: string) {
    const entry = this.registry[id]
    entry?.mod.upgrade?.(from)
  }

  list(): string[] {
    return Object.keys(this.registry)
  }
}

export const pluginHost = new PluginHost()